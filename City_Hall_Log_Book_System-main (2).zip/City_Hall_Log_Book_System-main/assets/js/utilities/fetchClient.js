import Fetch from "../helpers/fetch.js";

const fetch = new Fetch();

export default fetch;